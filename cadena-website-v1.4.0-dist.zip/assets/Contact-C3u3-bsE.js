import{L,a,b as s,d as e,M as T,F as E,l as K,w as u,e as h,t as _,h as y,m as M,N as S,r as C,o as V,k as B,f as z}from"./index-Bjie23IV.js";import{T as j}from"./TheFooter-CJ8BxUB-.js";import{_ as N}from"./_plugin-vue_export-helper-DlAUqK2U.js";const F={viewBox:"0 0 24 24",width:"1.2em",height:"1.2em"};function q(o,i){return s(),a("svg",F,[...i[0]||(i[0]=[e("path",{fill:"currentColor",d:"M23.498 6.186a3.02 3.02 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.02 3.02 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.02 3.02 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.02 3.02 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814M9.545 15.568V8.432L15.818 12z"},null,-1)])])}const H=L({name:"simple-icons-youtube",render:q}),G={viewBox:"0 0 24 24",width:"1.2em",height:"1.2em"};function R(o,i){return s(),a("svg",G,[...i[0]||(i[0]=[e("path",{fill:"currentColor",d:"M12 .297c-6.63 0-12 5.373-12 12c0 5.303 3.438 9.8 8.205 11.385c.6.113.82-.258.82-.577c0-.285-.01-1.04-.015-2.04c-3.338.724-4.042-1.61-4.042-1.61C4.422 18.07 3.633 17.7 3.633 17.7c-1.087-.744.084-.729.084-.729c1.205.084 1.838 1.236 1.838 1.236c1.07 1.835 2.809 1.305 3.495.998c.108-.776.417-1.305.76-1.605c-2.665-.3-5.466-1.332-5.466-5.93c0-1.31.465-2.38 1.235-3.22c-.135-.303-.54-1.523.105-3.176c0 0 1.005-.322 3.3 1.23c.96-.267 1.98-.399 3-.405c1.02.006 2.04.138 3 .405c2.28-1.552 3.285-1.23 3.285-1.23c.645 1.653.24 2.873.12 3.176c.765.84 1.23 1.91 1.23 3.22c0 4.61-2.805 5.625-5.475 5.92c.42.36.81 1.096.81 2.22c0 1.606-.015 2.896-.015 3.286c0 .315.21.69.825.57C20.565 22.092 24 17.592 24 12.297c0-6.627-5.373-12-12-12"},null,-1)])])}const Z=L({name:"simple-icons-github",render:R}),W={viewBox:"0 0 24 24",width:"1.2em",height:"1.2em"};function X(o,i){return s(),a("svg",W,[...i[0]||(i[0]=[e("path",{fill:"currentColor",d:"M18.901 1.153h3.68l-8.04 9.19L24 22.846h-7.406l-5.8-7.584l-6.638 7.584H.474l8.6-9.83L0 1.154h7.594l5.243 6.932ZM17.61 20.644h2.039L6.486 3.24H4.298Z"},null,-1)])])}const J=L({name:"simple-icons-x",render:X}),D="/img/kevinb-640.avif",Q="/img/kevinb-960.avif",ee="/img/kevinb-1280.avif",O="/img/Sz-640.avif",te="/img/Sz-960.avif",ie="/img/Sz-1280.avif";/**
 * @license lucide-vue-next v0.534.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const A=o=>o.replace(/([a-z0-9])([A-Z])/g,"$1-$2").toLowerCase(),se=o=>o.replace(/^([A-Z])|[\s-_]+(\w)/g,(i,l,n)=>n?n.toUpperCase():l.toLowerCase()),ae=o=>{const i=se(o);return i.charAt(0).toUpperCase()+i.slice(1)},oe=(...o)=>o.filter((i,l,n)=>!!i&&i.trim()!==""&&n.indexOf(i)===l).join(" ").trim();/**
 * @license lucide-vue-next v0.534.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */var b={xmlns:"http://www.w3.org/2000/svg",width:24,height:24,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor","stroke-width":2,"stroke-linecap":"round","stroke-linejoin":"round"};/**
 * @license lucide-vue-next v0.534.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const le=({size:o,strokeWidth:i=2,absoluteStrokeWidth:l,color:n,iconNode:c,name:m,class:f,...x},{slots:v})=>T("svg",{...b,width:o||b.width,height:o||b.height,stroke:n||b.stroke,"stroke-width":l?Number(i)*24/Number(o):i,class:oe("lucide",...m?[`lucide-${A(ae(m))}-icon`,`lucide-${A(m)}`]:["lucide-icon"]),...x},[...c.map(p=>T(...p)),...v.default?[v.default()]:[]]);/**
 * @license lucide-vue-next v0.534.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const w=(o,i)=>(l,{slots:n})=>T(le,{...l,iconNode:i,name:o},n);/**
 * @license lucide-vue-next v0.534.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const ne=w("building-2",[["path",{d:"M6 22V4a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v18Z",key:"1b4qmf"}],["path",{d:"M6 12H4a2 2 0 0 0-2 2v6a2 2 0 0 0 2 2h2",key:"i71pzd"}],["path",{d:"M18 9h2a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2h-2",key:"10jefs"}],["path",{d:"M10 6h4",key:"1itunk"}],["path",{d:"M10 10h4",key:"tcdvrf"}],["path",{d:"M10 14h4",key:"kelpxr"}],["path",{d:"M10 18h4",key:"1ulq68"}]]);/**
 * @license lucide-vue-next v0.534.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const I=w("check",[["path",{d:"M20 6 9 17l-5-5",key:"1gmf2c"}]]);/**
 * @license lucide-vue-next v0.534.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const re=w("chevron-down",[["path",{d:"m6 9 6 6 6-6",key:"qrunsl"}]]);/**
 * @license lucide-vue-next v0.534.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Y=w("copy",[["rect",{width:"14",height:"14",x:"8",y:"8",rx:"2",ry:"2",key:"17jyea"}],["path",{d:"M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2",key:"zix9uf"}]]);/**
 * @license lucide-vue-next v0.534.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const ce=w("mail",[["path",{d:"m22 7-8.991 5.727a2 2 0 0 1-2.009 0L2 7",key:"132q7q"}],["rect",{x:"2",y:"4",width:"20",height:"16",rx:"2",key:"izxlao"}]]);/**
 * @license lucide-vue-next v0.534.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const de=w("phone",[["path",{d:"M13.832 16.568a1 1 0 0 0 1.213-.303l.355-.465A2 2 0 0 1 17 15h3a2 2 0 0 1 2 2v3a2 2 0 0 1-2 2A18 18 0 0 1 2 4a2 2 0 0 1 2-2h3a2 2 0 0 1 2 2v3a2 2 0 0 1-.8 1.6l-.468.351a1 1 0 0 0-.292 1.233 14 14 0 0 0 6.392 6.384",key:"9njp5v"}]]);/**
 * @license lucide-vue-next v0.534.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const pe=w("user",[["path",{d:"M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2",key:"975kel"}],["circle",{cx:"12",cy:"7",r:"4",key:"17ys0d"}]]);/**
 * @license lucide-vue-next v0.534.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const ue=w("users",[["path",{d:"M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2",key:"1yyitq"}],["path",{d:"M16 3.128a4 4 0 0 1 0 7.744",key:"16gr8j"}],["path",{d:"M22 21v-2a4 4 0 0 0-3-3.87",key:"kshegd"}],["circle",{cx:"9",cy:"7",r:"4",key:"nufk8"}]]),me={class:"w-full px-6 py-5 md:py-5","aria-labelledby":"usecases-title"},he={class:"max-w-6xl mx-auto space-y-8"},ye={class:"space-y-4"},we=["open"],xe=["aria-controls"],ve={class:"uc-title"},fe={class:"teaser text-sm text-white/70 mt-1"},ge=["id"],be=["innerHTML"],_e={__name:"UseCasesAccordion",props:{items:{type:Array,default:()=>[]}},setup(o){const i={mounted(l,n){var x;l.classList.add("reveal");const c=Number(((x=n==null?void 0:n.value)==null?void 0:x.delay)??0),m=Number.isFinite(c)&&c>=0&&c<=2e3?c:0;l.style.transitionDelay=`${m}ms`;const f=new IntersectionObserver(([v])=>{v.isIntersecting&&(l.classList.add("in"),f.unobserve(l))},{rootMargin:"0px 0px -10% 0px",threshold:.08});f.observe(l)}};return(l,n)=>(s(),a("section",me,[e("div",he,[n[0]||(n[0]=e("h2",{id:"usecases-title",class:"section-title text-center"},"Use cases",-1)),e("ul",ye,[(s(!0),a(E,null,K(o.items,(c,m)=>(s(),a("li",{key:c.id??m},[u((s(),a("details",{class:"pro-card group reveal",open:c.open===!0},[e("summary",{class:"flex items-start justify-between gap-4 cursor-pointer list-none select-none","aria-controls":`uc-panel-${m}`},[e("div",null,[e("h3",ve,_(c.title),1),e("p",fe,_(c.teaser),1)]),h(y(re),{class:"chev w-5 h-5 shrink-0 transition-transform duration-200","aria-hidden":"true"})],8,xe),e("div",{class:"mt-4 text-white/90 leading-relaxed",id:`uc-panel-${m}`},[typeof c.content=="string"?(s(),a("div",{key:0,innerHTML:c.content},null,8,be)):(s(),M(S(c.content),{key:1}))],8,ge)],8,we)),[[i,{delay:m*60}]])]))),128))])])]))}},ke=N(_e,[["__scopeId","data-v-dd772427"]]),Ce=D+" 640w, "+Q+" 960w, "+ee+" 1280w",Be=O+" 640w, "+te+" 960w, "+ie+" 1280w",Te={class:"min-h-screen text-white relative overflow-hidden bg-page-gradient"},Me={class:"w-full pt-28 md:pt-32","aria-labelledby":"onboarding-title"},Se={class:"mx-auto max-w-screen-xl px-6 sm:px-8 lg:px-12 space-y-10"},Le={class:"text-center"},$e={class:"grid grid-cols-1 md:grid-cols-2 gap-6"},ze={class:"pro-card group"},Ae={class:"flex items-start gap-4"},Ie={class:"icon-wrap"},Ye={class:"flex-1"},Ee={class:"mt-5 flex flex-wrap items-center gap-3"},Ne=["aria-label"],De={class:"text-sm font-medium"},Oe={class:"pro-card group"},Pe={class:"flex items-start gap-4"},Ue={class:"icon-wrap"},Ke={class:"flex-1"},Ve={class:"mt-5 flex flex-wrap items-center gap-3"},je=["aria-label"],Fe={class:"text-sm font-medium"},qe={class:"w-full px-6 py-16 md:py-20"},He={class:"max-w-6xl mx-auto"},Ge={class:"section-title text-center"},Re={class:"space-y-8"},Ze={class:"grid grid-cols-1 md:grid-cols-3 gap-6"},We={class:"reveal glass-tile card-tight text-center group"},Xe={class:"reveal glass-tile card-tight text-center group"},Je={class:"reveal glass-tile card-tight text-center group"},Qe={class:"reveal glass-card text-center"},et={class:"w-full px-6 pb-16 md:pb-24"},tt={class:"max-w-6xl mx-auto space-y-12"},it={class:"section-title text-center"},st={class:"reveal glass-card"},at={class:"flex flex-wrap items-center justify-center gap-10 md:gap-12"},ot={href:"https://x.com/cadenabitcoin",target:"_blank",rel:"noopener noreferrer nofollow",referrerpolicy:"no-referrer","aria-label":"Visit us on X (Twitter)",class:"social-tile"},lt={href:"https://github.com/",target:"_blank",rel:"noopener noreferrer nofollow",referrerpolicy:"no-referrer","aria-label":"Visit our GitHub",class:"social-tile"},nt={href:"https://youtube.com/@cadenabitcoin?si=VNgOLehpTTVFELbt",target:"_blank",rel:"noopener noreferrer nofollow",referrerpolicy:"no-referrer","aria-label":"Visit our YouTube",class:"social-tile"},rt={class:"grid grid-cols-1 md:grid-cols-2 gap-8"},ct={class:"reveal glass-card"},dt={class:"reveal glass-card"},pt={__name:"Contact",setup(o){const i=C(!1),l=C(!1),n=C(!1);function c(){f("info@cadenabitcoin.com",i)}function m(){f("+13058311410",l)}function f(d,t){var r;(r=navigator.clipboard)!=null&&r.writeText?navigator.clipboard.writeText(d).then(()=>v(t)).catch(()=>x(d,t)):x(d,t)}function x(d,t){const r=document.createElement("textarea");r.value=d,r.setAttribute("readonly",""),r.style.position="absolute",r.style.left="-9999px",document.body.appendChild(r),r.select();try{document.execCommand("copy"),v(t)}finally{document.body.removeChild(r)}}function v(d){d.value=!0,n.value=!0,setTimeout(()=>{d.value=!1,n.value=!1},1500)}V(()=>{window.scrollTo(0,0)});const p={mounted(d,t){var $;d.classList.add("reveal");const r=Number((($=t==null?void 0:t.value)==null?void 0:$.delay)??0),k=Number.isFinite(r)&&r>=0&&r<=2e3?r:0;d.style.transitionDelay=`${k}ms`;const g=new IntersectionObserver(([U])=>{U.isIntersecting&&(d.classList.add("in"),g.unobserve(d))},{rootMargin:"0px 0px -10% 0px",threshold:.08});g.observe(d)}},P=[{title:"“Mini Saylor” — Corporate Bitcoin Strategy",teaser:"Amplify BTC exposure without selling or draining cash.",content:`
      <p class="text-white/80">You're a Bitcoin maximalist who believes BTC will outperform long-term, but you want to add exposure without selling your stack or depleting cash.</p>

      <p class="mt-4 font-semibold text-white">Meet Alex: The Bitcoin Entrepreneur</p>
      <p class="text-white/80">“I run a tech company and hold 5 BTC personally. I’m convinced Bitcoin will hit $500K, but I don’t want to sell or use all my business capital to buy more.”</p>

      <p class="mt-4 font-semibold text-white">The Cadena Solution — Leverage Your Conviction, Keep Your Keys</p>
      <ul class="list-disc pl-5 space-y-1 text-white/80">
        <li>Decide how much additional exposure you want.</li>
        <li>Borrow additional Bitcoin based on risk tolerance and objectives.</li>
        <li>Use borrowed Bitcoin to increase your total position.</li>
        <li>Loan is settled in Bitcoin at term end (30, 90, 180 days, or 1 year).</li>
      </ul>

      <p class="mt-4 font-semibold text-white">The Process</p>
      <ol class="list-decimal pl-5 space-y-1 text-white/80">
        <li>Register on Cadena and download the signer app.</li>
        <li>Borrow additional Bitcoin at market rates (execute online, sign in app).</li>
        <li>Amplify your Bitcoin exposure without selling.</li>
        <li>Settle the loan in Bitcoin at maturity.</li>
      </ol>

      <p class="mt-4 font-semibold text-white">The Outcome</p>
      <ul class="list-disc pl-5 space-y-1 text-white/80">
        <li>✅ Increase your exposure from 0.05 BTC up to 5× stack leverage.</li>
        <li>✅ No taxable event — you never sold your original stack.</li>
        <li>✅ True self-custody throughout.</li>
        <li>✅ No KYC or banks — pure peer-to-peer Bitcoin finance.</li>
      </ul>

      <p class="mt-4 italic text-white/75">“Just like MicroStrategy’s strategy, but truly decentralized.”</p>

      <a href="/register" class="btn-primary mt-5 inline-flex" aria-label="Get Started">Get Started →</a>
    `},{title:"“Dividend Debbie” — Stable Bitcoin Yield",teaser:"Predictable BTC-denominated yield with custody intact.",content:`
      <p class="text-white/80">You want steady returns above traditional savings, without bank counterparty risk—while staying aligned with Bitcoin’s long-term upside.</p>

      <p class="mt-4 font-semibold text-white">Meet Debbie: The Yield Seeker</p>
      <p class="text-white/80">“I have 10 BTC sitting idle. Banks offer 0.5% while taking huge risks with my money. I want steady Bitcoin-denominated returns with real security.”</p>

      <p class="mt-4 font-semibold text-white">The Cadena Solution — Earn Yield, Keep Control</p>
      <ul class="list-disc pl-5 space-y-1 text-white/80">
        <li>Lend your Bitcoin on Cadena’s marketplace to earn fixed returns.</li>
        <li>Your Bitcoin is secured by math and Bitcoin collateral on-chain.</li>
        <li>No counterparty risk — borrower collateral protects your principal.</li>
        <li>You understand the risk of BTC moving below the loan-to-value over the term.</li>
      </ul>

      <p class="mt-4 font-semibold text-white">The Process</p>
      <ol class="list-decimal pl-5 space-y-1 text-white/80">
        <li>Register and download Cadena’s signer app.</li>
        <li>Choose lending terms (30, 90, 180 days, or 1 year).</li>
        <li>Set your desired yield rate; use a market or limit order.</li>
        <li>Match with borrowers.</li>
        <li>Earn Bitcoin-denominated returns.</li>
      </ol>

      <p class="mt-4 font-semibold text-white">The Outcome</p>
      <ul class="list-disc pl-5 space-y-1 text-white/80">
        <li>✅ Predictable yield — fiat-style yield, denominated in Bitcoin.</li>
        <li>✅ Your keys, your coins — maintain custody.</li>
        <li>✅ No bank risk — peer-to-peer with mathematical security.</li>
      </ul>

      <p class="mt-4 italic text-white/75">“Like being a preferred shareholder in MicroStrategy, but with better security.”</p>

      <a href="/register" class="btn-primary mt-5 inline-flex" aria-label="Start Lending">Start Lending →</a>
    `},{title:"“Borrowing for the Boat” — Liquidity Without Selling",teaser:"Access $50K without selling BTC or triggering tax.",content:`
      <p class="text-white/80">You need $50,000 for a purchase but don’t want to sell BTC, miss potential upside, or trigger a taxable event.</p>

      <p class="mt-4 font-semibold text-white">Meet Captain Mike: The Bitcoin HODLer</p>
      <p class="text-white/80">“I need $50K for my dream boat, but selling Bitcoin feels like selling Amazon in 1999. There has to be a better way.”</p>

      <p class="mt-4 font-semibold text-white">The Cadena Solution — Access Liquidity, Keep Your Bitcoin</p>
      <ul class="list-disc pl-5 space-y-1 text-white/80">
        <li>Use your Bitcoin as collateral for a Bitcoin loan.</li>
        <li>Borrow Bitcoin to maintain your desired exposure.</li>
        <li>Convert borrowed Bitcoin to USD for your purchase.</li>
        <li>Repay the loan by buying back Bitcoin at maturity.</li>
      </ul>

      <p class="mt-4 font-semibold text-white">The Process (example)</p>
      <ol class="list-decimal pl-5 space-y-1 text-white/80">
        <li>Borrow 0.5 BTC for 1 year (assuming BTCUSD = $100,000).</li>
        <li>Convert borrowed BTC to USD on your exchange of choice.</li>
        <li>Buy your boat with the proceeds.</li>
        <li>At term end, buy back 0.5 BTC and repay the loan.</li>
      </ol>

      <p class="mt-4 font-semibold text-white">The Outcome</p>
      <ul class="list-disc pl-5 space-y-1 text-white/80">
        <li>✅ Get your boat without selling your stack.</li>
        <li>✅ Maintain upside — you still own your original BTC.</li>
        <li>✅ True self-custody — your keys, your control.</li>
        <li>• Conservative risk management: 50% LTV gives a wide buffer.</li>
        <li>• No margin calls: collateral only matters at final settlement.</li>
      </ul>

      <p class="mt-4 italic text-white/75">“Enjoy life today while staying positioned for Bitcoin’s future.”</p>

      <a href="/register" class="btn-primary mt-5 inline-flex" aria-label="Borrow Now">Borrow Now →</a>
    `},{title:"“Yield Arber” — Advanced Bitcoin Strategies",teaser:"Capture spreads while keeping BTC exposure.",content:`
      <p class="text-white/80">You’re sophisticated with capital and want to maximize returns by arbitraging between BTC lending rates and other opportunities—without sacrificing exposure.</p>

      <p class="mt-4 font-semibold text-white">Meet Sarah: The Yield Arbitrageur</p>
      <p class="text-white/80">“I see Cadena lenders earning ~10% while I can borrow fiat at ~5%, or have savings sitting idle. I want to increase the dollar value of my BTC position by earning yield on my stack.”</p>

      <p class="mt-4 font-semibold text-white">The Cadena Solution — The Spread Play</p>
      <ul class="list-disc pl-5 space-y-1 text-white/80">
        <li>Lend Bitcoin on Cadena while borrowing fiat elsewhere at lower rates.</li>
        <li>✅ Maximize capital efficiency.</li>
        <li>✅ Maintain Bitcoin exposure.</li>
        <li>✅ Keep full custody — minimize counterparty risk.</li>
      </ul>

      <p class="mt-4 font-semibold text-white">Risk Considerations</p>
      <ul class="list-disc pl-5 space-y-1 text-white/80">
        <li>Leverage involves risk.</li>
        <li>Understand settlement mechanics.</li>
        <li>Plan for multiple BTC price scenarios.</li>
      </ul>

      <p class="mt-4 italic text-white/75">“For those who understand Bitcoin deeply and want to maximize every satoshi.”</p>

      <a href="/register" class="btn-primary mt-5 inline-flex" aria-label="Explore Opportunities">Explore Opportunities →</a>
    `}];return(d,t)=>{const r=J,k=Z,g=H;return s(),a(E,null,[e("div",Te,[t[21]||(t[21]=e("div",{class:"glow-purple","aria-hidden":"true"},null,-1)),t[22]||(t[22]=e("div",{class:"glow-cyan","aria-hidden":"true"},null,-1)),e("section",Me,[e("div",Se,[u((s(),a("div",Le,[...t[0]||(t[0]=[e("h1",{id:"onboarding-title",class:"section-title"}," Personalized Onboarding ",-1),e("p",{class:"lead max-w-4xl mx-auto"}," As a Cadena Bitcoin client, expert knowledge is always just a chat, email, or phone call away. We simplify complexity and are available 24/7 for personalized onboarding and strategies to borrow Bitcoin or generate yield from Bitcoin. ",-1)])])),[[p]]),e("div",$e,[u((s(),a("div",ze,[e("div",Ae,[e("div",Ie,[h(y(de),{class:"w-5 h-5","aria-hidden":"true"})]),e("div",Ye,[t[2]||(t[2]=e("h4",{class:"text-2xl font-semibold"},"Call",-1)),t[3]||(t[3]=e("p",{class:"text-sm text-white/70 mt-1"},"Speak to our team anytime.",-1)),e("div",Ee,[t[1]||(t[1]=e("a",{href:"tel:+13058311410",class:"btn-primary","aria-label":"Call (305) 831-1410"}," (305) 831-1410 ",-1)),e("button",{onClick:m,class:"btn-ghost","aria-label":l.value?"Copied phone number":"Copy phone number"},[(s(),M(S(l.value?y(I):y(Y)),{class:"w-4 h-4"})),e("span",De,_(l.value?"Copied":"Copy"),1)],8,Ne)]),t[4]||(t[4]=e("div",{class:"mt-4 flex items-center gap-3 text-xs text-white/60"},[e("span",{class:"inline-flex items-center gap-1"},[e("span",{class:"h-1.5 w-1.5 rounded-full bg-emerald-400/80"}),B(" Live support ")]),e("span",null,"Response time: < 24h")],-1))])])])),[[p,{delay:60}]]),u((s(),a("div",Oe,[e("div",Pe,[e("div",Ue,[h(y(ce),{class:"w-5 h-5","aria-hidden":"true"})]),e("div",Ke,[t[6]||(t[6]=e("h4",{class:"text-2xl font-semibold"},"Email",-1)),t[7]||(t[7]=e("p",{class:"text-sm text-white/70 mt-1"},"Send us your questions or request onboarding.",-1)),e("div",Ve,[t[5]||(t[5]=e("a",{href:"mailto:info@cadenabitcoin.com",class:"btn-primary","aria-label":"Email info@cadenabitcoin.com"}," info@cadenabitcoin.com ",-1)),e("button",{onClick:c,class:"btn-ghost","aria-label":i.value?"Copied email":"Copy email"},[(s(),M(S(i.value?y(I):y(Y)),{class:"w-4 h-4"})),e("span",Fe,_(i.value?"Copied":"Copy"),1)],8,je)]),t[8]||(t[8]=e("div",{class:"mt-4 flex items-center gap-3 text-xs text-white/60"},[e("span",null,"Dedicated onboarding specialist"),e("span",{"aria-hidden":"true"},"•"),e("span",null,"Secure & private")],-1))])])])),[[p,{delay:100}]])])])]),e("section",qe,[e("div",He,[u((s(),a("h2",Ge,[...t[9]||(t[9]=[B("Who we serve.",-1)])])),[[p]]),e("div",Re,[e("div",Ze,[u((s(),a("div",We,[h(y(pe),{class:"w-8 h-8 mx-auto mb-3 text-white/80 group-hover:text-white","aria-hidden":"true"}),t[10]||(t[10]=e("p",{class:"text-xl font-semibold"},"Individual Investors",-1))])),[[p,{delay:40}]]),u((s(),a("div",Xe,[h(y(ue),{class:"w-8 h-8 mx-auto mb-3 text-white/80 group-hover:text-white","aria-hidden":"true"}),t[11]||(t[11]=e("p",{class:"text-xl font-semibold"},"Family Offices",-1))])),[[p,{delay:90}]]),u((s(),a("div",Je,[h(y(ne),{class:"w-8 h-8 mx-auto mb-3 text-white/80 group-hover:text-white","aria-hidden":"true"}),t[12]||(t[12]=e("p",{class:"text-xl font-semibold"},"Institutional Investors",-1))])),[[p,{delay:140}]])]),u((s(),a("div",Qe,[...t[13]||(t[13]=[e("p",{class:"text-2xl text-white/90"}," Get expert support and competitive rates for Bitcoin borrowing and lending. ",-1)])])),[[p,{delay:180}]])])])]),h(ke,{items:P}),e("section",et,[e("div",tt,[u((s(),a("h2",it,[...t[14]||(t[14]=[B("Reach Out",-1)])])),[[p]]),u((s(),a("div",st,[t[18]||(t[18]=e("p",{class:"text-2xl font-semibold mb-8 text-center"},"Find Us On Social Media",-1)),e("div",at,[e("a",ot,[h(r,{class:"w-16 h-16 md:w-20 md:h-20","aria-hidden":"true"}),t[15]||(t[15]=e("span",{class:"text-base font-medium"},"X",-1))]),e("a",lt,[h(k,{class:"w-16 h-16 md:w-20 md:h-20","aria-hidden":"true"}),t[16]||(t[16]=e("span",{class:"text-base font-medium"},"GitHub",-1))]),e("a",nt,[h(g,{class:"w-16 h-16 md:w-20 md:h-20","aria-hidden":"true"}),t[17]||(t[17]=e("span",{class:"text-base font-medium"},"YouTube",-1))])])])),[[p,{delay:60}]]),e("div",rt,[u((s(),a("div",ct,[...t[19]||(t[19]=[z('<div class="avatar-wrap mb-3" data-v-a6479d06><img src="'+D+'" srcset="'+Ce+'" sizes="(min-width: 768px) 192px, 160px" alt="Kevin Bell headshot" class="headshot" width="160" height="160" loading="lazy" decoding="async" data-v-a6479d06></div><p class="text-xl font-semibold mb-1" data-v-a6479d06>Kevin Bell</p><p class="text-sm text-white/70" data-v-a6479d06>President • CFA</p><p class="mt-3 text-white/80 text-sm leading-relaxed" data-v-a6479d06> Kevin Bell, CFA — tradfi graduate, capital markets veteran, debt and currency dealer, and numbers ninja. Passionate about building efficient financial solutions that promote Bitcoin, freedom, decentralization, and individual empowerment. </p><div class="mt-4 space-y-1" data-v-a6479d06><p data-v-a6479d06><span class="font-medium" data-v-a6479d06>Email:</span><a href="mailto:kevin@cadenabitcoin.com" class="underline hover:opacity-80" data-v-a6479d06>kevin@cadenabitcoin.com</a></p><p data-v-a6479d06><span class="font-medium" data-v-a6479d06>Phone:</span><a href="tel:+13058311410" class="underline hover:opacity-80" data-v-a6479d06>305-831-1410</a></p></div>',5)])])),[[p,{delay:80}]]),u((s(),a("div",dt,[...t[20]||(t[20]=[z('<div class="avatar-wrap mb-3" data-v-a6479d06><img src="'+O+'" srcset="'+Be+'" sizes="(min-width: 768px) 192px, 160px" alt="Sziller headshot" class="headshot" width="160" height="160" loading="lazy" decoding="async" data-v-a6479d06></div><p class="text-xl font-semibold mb-1" data-v-a6479d06>Sziller</p><p class="text-sm text-white/70" data-v-a6479d06>Chief Technology Officer</p><p class="mt-3 text-white/80 text-sm leading-relaxed" data-v-a6479d06> Sziller, an Engineer and M.Sc. Architect with decentralization and self-sufficiency on my mind. I’m interested in Engineering solutions for real-life problems accessible to anyone, with skunkswork philosophy. I strive to achieve optimal redundancy by cutting out as many middle-men as possible. I love solutions that work, even if rough on the edges. </p><div class="mt-4 space-y-1" data-v-a6479d06><p data-v-a6479d06><span class="font-medium" data-v-a6479d06>Email:</span><a href="mailto:sziller@cadenabitcoin.com" class="underline hover:opacity-80" data-v-a6479d06>sziller@cadenabitcoin.com</a></p></div>',5)])])),[[p,{delay:120}]])])])])]),h(j)],64)}}},yt=N(pt,[["__scopeId","data-v-a6479d06"]]);export{yt as default};
