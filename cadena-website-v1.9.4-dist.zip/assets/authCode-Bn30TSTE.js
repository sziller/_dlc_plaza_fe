const i=r=>{const e=Number(r);return Number.isFinite(e)?(e&4)===4:!1};export{i};
