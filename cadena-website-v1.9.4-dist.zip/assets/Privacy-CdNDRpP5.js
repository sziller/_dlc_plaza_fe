import{T as f}from"./TheFooter-Dr7ErcNN.js";import{_ as g,r as d,c as v,o as b,b as w,d as r,e as P,t as k,F as x,l as _}from"./index-Cll56lgu.js";const W={class:"min-h-screen text-white pt-20 md:pt-24 relative bg-page-gradient"},B={class:"px-6 py-12 md:py-16 text-center"},Y={class:"text-3xl md:text-5xl font-extrabold leading-tight"},C={class:"max-w-4xl mx-auto px-6 pb-16"},T=["innerHTML"],I=`
Privacy Policy for Cadena Bitcoin

Effective Date: October 1, 2025


At Cadena Bitcoin ("we," "us," or "our"), we are committed to protecting your privacy. This Privacy Policy outlines how we collect, use, store, and protect your personal information when you use our Bitcoin borrowing and lending platform (the "Platform"). By accessing or using the Platform, you agree to the terms of this Privacy Policy.


1. Non-KYC Platform and User Responsibility

Cadena Bitcoin is a non-KYC platform, meaning we do not require identity verification documents or other personally identifiable information beyond what is outlined in this policy. You are solely responsible for securing and managing your private keys associated with your Bitcoin used on the Platform. We do not store, control, or have access to your private keys. Loss of private keys may result in permanent loss of access to your Bitcoin, and Cadena Bitcoin is not liable for such losses.


2. Information We Collect

We collect only the minimum information necessary to provide our services:


Email Address: Used for account creation, communication, and recovery purposes.

Password: A hashed version of your password is stored to authenticate your access to the Platform.

Usage Data: We may collect non-identifying information about how you interact with the Platform, such as IP addresses, browser type, device information, and timestamps of activities (e.g., logins, transactions, or borrowing/lending activities).

Bitcoin Transaction Data: Information related to your borrowing and lending activities, such as wallet addresses, transaction IDs, and amounts, which are recorded on the Bitcoin blockchain and may be linked to your account for operational purposes.


We do not collect sensitive personal information such as your name, address, date of birth, or government-issued identification.


3. How We Use Your Information

We use the information we collect to:


- Provide and maintain the Platform’s borrowing and lending services.

- Authenticate your account and secure your access.

- Communicate with you about your account, transactions, or Platform updates.

- Monitor and analyze usage to improve the Platform’s functionality and user experience.

- Ensure compliance with our Terms of Service and applicable laws.

- Protect against fraud, unauthorized access, or other illegal activities.


4. How We Store and Protect Your Information

Data Security: We implement industry-standard security measures, such as encryption and secure hashing for passwords, to protect your data. No system is completely secure, and you acknowledge the risks of using online platforms.

Data Storage: Your email and hashed password are stored on secure servers. Bitcoin transaction data is stored only as necessary to facilitate borrowing and lending and is not linked to personally identifiable information beyond your email.

Private Keys: As a custodial platform where you control your private keys, we do not store or have access to your private keys. You are responsible for securely storing and backing up your private keys.


5. Sharing Your Information

We do not sell, trade, or share your personal information with third parties, except in the following cases:


Service Providers: We may share limited data with service providers (e.g., hosting, email, or analytics providers) to operate the Platform. These providers are contractually obligated to protect your data and use it only for the services they provide to us.

Legal Requirements: We may disclose your information if required by law, court order, or other legal processes, or to protect our rights, property, or safety, or that of our users.

Blockchain Data: Bitcoin transactions, including wallet addresses and amounts, are recorded on the public Bitcoin blockchain and are inherently visible to anyone. We do not link this data to your email or other personal information in a way that identifies you.


6. Your Choices and Rights

Account Management: You may update your email or password at any time through your account settings.

Data Deletion: You may request deletion of your account by contacting us at info@cadenabitcoin.com. Upon deletion, we will remove your email and hashed password from our systems, though blockchain transaction data cannot be deleted due to its immutable nature.

Opt-Out: You may opt out of non-essential communications (e.g., promotional emails) by following the unsubscribe instructions in those emails.


7. Cookies and Tracking Technologies

We may use cookies or similar technologies to enhance your experience, such as remembering your login session or analyzing usage patterns. You can manage cookie preferences through your browser settings, but disabling cookies may affect the Platform’s functionality.


8. Third-Party Links

The Platform may contain links to third-party websites or services. We are not responsible for the privacy practices or content of these third parties. We encourage you to review their privacy policies before engaging with them.


9. International Users

Cadena Bitcoin operates globally, and your data may be stored or processed in jurisdictions outside your country of residence. By using the Platform, you consent to the transfer of your data to such jurisdictions, which may have different data protection laws.


10. Changes to This Privacy Policy

We may update this Privacy Policy from time to time to reflect changes in our practices or legal requirements. We will notify you of material changes by posting the updated policy on the Platform or via email. Your continued use of the Platform after such changes constitutes acceptance of the updated policy.


11. Contact Us

If you have questions or concerns about this Privacy Policy or our data practices, please contact us at:

Info@cadenabitcoin.com

Www.cadenabitcoin.com
`,A={__name:"Privacy",setup(D){const c=d(""),l=d("");function m(a){return a.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;")}function y(a){let o=a.replace(/\bhttps?:\/\/[^\s<>"']+/g,e=>`<a href="${e}" target="_blank" rel="noopener noreferrer nofollow" class="text-secondary underline hover:text-secondary/80">${e}</a>`);return o=o.replace(/\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b/gi,e=>`<a href="mailto:${e}" class="text-secondary underline hover:text-secondary/80">${e}</a>`),o}function h(a){const e=m(a.trim()).split(`
`),n=e.findIndex(i=>i.trim().length);n>=0&&(l.value=e[n].trim(),e[n]="");let s=e.join(`
`).trim().replace(/^(\d+)\.\s+(.+)$/gm,(i,t,u)=>`<h2 id="s${t}" class="mt-10 text-2xl font-bold">${t}. ${u}</h2>`);return s=s.split(/\n{2,}/).map(i=>{const t=i.trim();return t?t.startsWith("<h2")?t:`<p class="leading-relaxed">${y(t).replace(/\n/g,"<br>")}</p>`:""}).join(`
`),s}const p=v(()=>h(c.value));return b(()=>{c.value=I}),(a,o)=>(_(),w(x,null,[r("main",W,[o[0]||(o[0]=r("div",{class:"bg-fixed-gradient","aria-hidden":"true"},null,-1)),r("section",B,[r("h1",Y,k(l.value||"Privacy Policy"),1)]),r("section",C,[r("article",{class:"prose prose-invert max-w-none",innerHTML:p.value},null,8,T)])]),P(f)],64))}},U=g(A,[["__scopeId","data-v-2af2e78b"]]);export{U as default};
