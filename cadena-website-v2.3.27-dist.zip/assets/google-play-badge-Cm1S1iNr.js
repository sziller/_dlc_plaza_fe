const g="/img/google-play-badge.png";export{g as _};
