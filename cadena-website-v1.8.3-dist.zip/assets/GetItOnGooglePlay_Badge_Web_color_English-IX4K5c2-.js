const o="/img/GetItOnGooglePlay_Badge_Web_color_English.svg";export{o as _};
