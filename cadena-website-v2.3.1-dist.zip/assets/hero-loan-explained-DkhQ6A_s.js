const o="/img/hero-loan-explained.png";export{o as _};
