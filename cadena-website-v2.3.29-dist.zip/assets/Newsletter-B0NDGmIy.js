import{P as i,r,o as F,f as l,g as e,i as k,M as O,C as d,h as f,j as c,q as N,L as T,p,v as u,t as m,F as w,B as L,Q as B,y as a}from"./vendor-vue-_2sTnOoV.js";import{T as Y}from"./TheFooter-BzQaH9He.js";import{i as W,p as G}from"./publicContact-q5d4ggac.js";import{a as H}from"./index-D3ZgSo-h.js";import{c as o,M as K,U as $}from"./users-CfzpdaK0.js";import"./vendor-http-B9ygI19o.js";/**
 * @license lucide-vue-next v0.534.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Z=o("calendar-check",[["path",{d:"M8 2v4",key:"1cmpym"}],["path",{d:"M16 2v4",key:"4m81vk"}],["rect",{width:"18",height:"18",x:"3",y:"4",rx:"2",key:"1hopcy"}],["path",{d:"M3 10h18",key:"8toen8"}],["path",{d:"m9 16 2 2 4-4",key:"19s6y9"}]]);/**
 * @license lucide-vue-next v0.534.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const J=o("chart-column",[["path",{d:"M3 3v16a2 2 0 0 0 2 2h16",key:"c24i48"}],["path",{d:"M18 17V9",key:"2bz60n"}],["path",{d:"M13 17V5",key:"1frdt8"}],["path",{d:"M8 17v-3",key:"17ska0"}]]);/**
 * @license lucide-vue-next v0.534.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const A=o("circle-alert",[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["line",{x1:"12",x2:"12",y1:"8",y2:"12",key:"1pkeuh"}],["line",{x1:"12",x2:"12.01",y1:"16",y2:"16",key:"4dfq90"}]]);/**
 * @license lucide-vue-next v0.534.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const j=o("circle-check-big",[["path",{d:"M21.801 10A10 10 0 1 1 17 3.335",key:"yps3ct"}],["path",{d:"m9 11 3 3L22 4",key:"1pflzl"}]]);/**
 * @license lucide-vue-next v0.534.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Q=o("coins",[["circle",{cx:"8",cy:"8",r:"6",key:"3yglwk"}],["path",{d:"M18.09 10.37A6 6 0 1 1 10.34 18",key:"t5s6rm"}],["path",{d:"M7 6h1v4",key:"1obek4"}],["path",{d:"m16.71 13.88.7.71-2.82 2.82",key:"1rbuyh"}]]);/**
 * @license lucide-vue-next v0.534.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const X=o("file-code-2",[["path",{d:"M4 22h14a2 2 0 0 0 2-2V7l-5-5H6a2 2 0 0 0-2 2v4",key:"1pf5j1"}],["path",{d:"M14 2v4a2 2 0 0 0 2 2h4",key:"tnqrlb"}],["path",{d:"m5 12-3 3 3 3",key:"oke12k"}],["path",{d:"m9 18 3-3-3-3",key:"112psh"}]]);/**
 * @license lucide-vue-next v0.534.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const ee=o("globe",[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["path",{d:"M12 2a14.5 14.5 0 0 0 0 20 14.5 14.5 0 0 0 0-20",key:"13o1zl"}],["path",{d:"M2 12h20",key:"9i4pu4"}]]);/**
 * @license lucide-vue-next v0.534.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const te=o("graduation-cap",[["path",{d:"M21.42 10.922a1 1 0 0 0-.019-1.838L12.83 5.18a2 2 0 0 0-1.66 0L2.6 9.08a1 1 0 0 0 0 1.832l8.57 3.908a2 2 0 0 0 1.66 0z",key:"j76jl0"}],["path",{d:"M22 10v6",key:"1lu8f3"}],["path",{d:"M6 12.5V16a6 3 0 0 0 12 0v-3.5",key:"1r8lef"}]]);/**
 * @license lucide-vue-next v0.534.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const se=o("key-round",[["path",{d:"M2.586 17.414A2 2 0 0 0 2 18.828V21a1 1 0 0 0 1 1h3a1 1 0 0 0 1-1v-1a1 1 0 0 1 1-1h1a1 1 0 0 0 1-1v-1a1 1 0 0 1 1-1h.172a2 2 0 0 0 1.414-.586l.814-.814a6.5 6.5 0 1 0-4-4z",key:"1s6t7t"}],["circle",{cx:"16.5",cy:"7.5",r:".5",fill:"currentColor",key:"w0ekpg"}]]);/**
 * @license lucide-vue-next v0.534.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const D=o("loader-circle",[["path",{d:"M21 12a9 9 0 1 1-6.219-8.56",key:"13zald"}]]);/**
 * @license lucide-vue-next v0.534.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const ae=o("lock",[["rect",{width:"18",height:"11",x:"3",y:"11",rx:"2",ry:"2",key:"1w4ew1"}],["path",{d:"M7 11V7a5 5 0 0 1 10 0v4",key:"fwvmzm"}]]);/**
 * @license lucide-vue-next v0.534.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const oe=o("megaphone",[["path",{d:"M11 6a13 13 0 0 0 8.4-2.8A1 1 0 0 1 21 4v12a1 1 0 0 1-1.6.8A13 13 0 0 0 11 14H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2z",key:"q8bfy3"}],["path",{d:"M6 14a12 12 0 0 0 2.4 7.2 2 2 0 0 0 3.2-2.4A8 8 0 0 1 10 14",key:"1853fq"}],["path",{d:"M8 6v8",key:"15ugcq"}]]);/**
 * @license lucide-vue-next v0.534.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const ie=o("pen",[["path",{d:"M21.174 6.812a1 1 0 0 0-3.986-3.987L3.842 16.174a2 2 0 0 0-.5.83l-1.321 4.352a.5.5 0 0 0 .623.622l4.353-1.32a2 2 0 0 0 .83-.497z",key:"1a8usu"}]]);/**
 * @license lucide-vue-next v0.534.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const le=o("rocket",[["path",{d:"M4.5 16.5c-1.5 1.26-2 5-2 5s3.74-.5 5-2c.71-.84.7-2.13-.09-2.91a2.18 2.18 0 0 0-2.91-.09z",key:"m3kijz"}],["path",{d:"m12 15-3-3a22 22 0 0 1 2-3.95A12.88 12.88 0 0 1 22 2c0 2.72-.78 7.5-6 11a22.35 22.35 0 0 1-4 2z",key:"1fmvmk"}],["path",{d:"M9 12H4s.55-3.03 2-4c1.62-1.08 5 0 5 0",key:"1f8sc4"}],["path",{d:"M12 15v5s3.03-.55 4-2c1.08-1.62 0-5 0-5",key:"qeys4"}]]);/**
 * @license lucide-vue-next v0.534.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const ne=o("scale",[["path",{d:"m16 16 3-8 3 8c-.87.65-1.92 1-3 1s-2.13-.35-3-1Z",key:"7g6ntu"}],["path",{d:"m2 16 3-8 3 8c-.87.65-1.92 1-3 1s-2.13-.35-3-1Z",key:"ijws7r"}],["path",{d:"M7 21h10",key:"1b0cd5"}],["path",{d:"M12 3v18",key:"108xh3"}],["path",{d:"M3 7h2c2 0 5-1 7-2 2 1 5 2 7 2h2",key:"3gwbw2"}]]);/**
 * @license lucide-vue-next v0.534.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const P=o("send",[["path",{d:"M14.536 21.686a.5.5 0 0 0 .937-.024l6.5-19a.496.496 0 0 0-.635-.635l-19 6.5a.5.5 0 0 0-.024.937l7.93 3.18a2 2 0 0 1 1.112 1.11z",key:"1ffxy3"}],["path",{d:"m21.854 2.147-10.94 10.939",key:"12cjpa"}]]);/**
 * @license lucide-vue-next v0.534.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const ce=o("shield",[["path",{d:"M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z",key:"oel41y"}]]);/**
 * @license lucide-vue-next v0.534.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const re=o("trending-up",[["path",{d:"M16 7h6v6",key:"box55l"}],["path",{d:"m22 7-8.5 8.5-5-5L2 17",key:"1t1m79"}]]),de={class:"newsletter-root min-h-screen text-white"},ue={class:"top-section","aria-labelledby":"hero-title"},me={class:"max-w-screen-xl mx-auto px-6 sm:px-8 lg:px-12"},pe={class:"signup-card mt-10 max-w-lg mx-auto"},he={class:"signup-icon"},ye=["disabled"],ve={key:0,class:"msg msg-success mt-3"},ke={key:1,class:"msg msg-error mt-3"},be={class:"px-6 py-10 md:py-14","aria-labelledby":"value-title"},xe={class:"max-w-screen-xl mx-auto"},ge={class:"text-center mb-12"},fe={class:"grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5"},we={class:"value-icon"},Me={class:"text-lg font-bold text-white mb-1"},_e={class:"text-sm text-white/65 leading-relaxed"},Ce={class:"px-6 py-10 md:py-14","aria-labelledby":"topics-title"},Se={class:"max-w-screen-xl mx-auto"},Le={class:"text-center mb-12"},Be={class:"glass-card topics-grid"},Ve={class:"topics-left"},ze={class:"trust-signals"},Ee={class:"trust-row-icon"},Ne={class:"trust-row-text"},Te={class:"topics-right"},Ae={class:"topic-chips"},je={class:"w-full px-6 pb-16 md:pb-20","aria-labelledby":"cta-title"},De={class:"max-w-3xl mx-auto text-center"},Pe=["disabled"],Re={key:0,class:"msg msg-success mt-4 justify-center"},Ue={key:1,class:"msg msg-error mt-4 justify-center"},qe={__name:"Newsletter",setup(Ie){const R=[{icon:i(te),title:"Bitcoin Education",desc:"Deep dives into how Bitcoin lending, DLCs, and self-custody actually work — written for humans."},{icon:i(re),title:"Market Insights",desc:"Macro analysis and on-chain data that help you make informed decisions, not emotional ones."},{icon:i(ce),title:"Security Best Practices",desc:"Practical guides on key management, multisig setups, and protecting your stack."},{icon:i(le),title:"Product Updates",desc:"Be the first to know about new Cadena features, rate changes, and platform improvements."}],U=[{icon:i(X),label:"Discreet Log Contracts"},{icon:i(ae),label:"Self-Custody Practices"},{icon:i(ee),label:"Macro & Bitcoin Thesis"},{icon:i(Q),label:"Yield & Lending"},{icon:i(J),label:"On-Chain Analytics"},{icon:i(se),label:"Security & Key Mgmt"},{icon:i(ne),label:"Regulatory Updates"},{icon:i(oe),label:"Product & Roadmap"}],q=[{icon:i($),text:"Growing community of self-sovereign investors"},{icon:i(ie),text:"Written by practitioners, not marketers"},{icon:i(Z),text:"Delivered weekly — no spam, ever"}],M=r(""),x=r(!1),V=r(!1),_=r(""),C=r(""),g=r(!1),z=r(!1),S=r("");async function E(n){const t=n==="top"?M:C,s=n==="top"?x:g,y=n==="top"?V:z,v=n==="top"?_:S;if(v.value="",y.value=!1,!W(t.value)){v.value="Please enter a valid email address.";return}s.value=!0;try{await G(t.value),y.value=!0,t.value=""}catch(b){v.value=b instanceof Error?b.message:"Something went wrong. Please try again."}finally{s.value=!1}}F(()=>{window.scrollTo(0,0)});const h={mounted(n,t){var b;n.classList.add("reveal");const s=Number(((b=t==null?void 0:t.value)==null?void 0:b.delay)??0),y=Number.isFinite(s)&&s>=0&&s<=2e3?s:0;n.style.transitionDelay=`${y}ms`;const v=new IntersectionObserver(([I])=>{I.isIntersecting&&(n.classList.add("in"),v.unobserve(n))},{rootMargin:"0px 0px -5% 0px",threshold:.05});v.observe(n)}};return(n,t)=>(a(),l(w,null,[e("div",de,[t[15]||(t[15]=e("div",{class:"bg-fixed-gradient","aria-hidden":"true"},null,-1)),e("section",ue,[e("div",me,[t[7]||(t[7]=O('<div class="text-center" data-v-9a61570c><p class="eyebrow" data-v-9a61570c>Stay Informed</p><h1 id="hero-title" class="section-title mt-2" data-v-9a61570c>The Bitcoin Education<br class="hidden sm:block" data-v-9a61570c> You Actually Need</h1><p class="lead max-w-3xl mx-auto mt-4" data-v-9a61570c> Clear analysis, no hype. Actionable insights on Bitcoin lending, self-custody, and building real wealth — delivered straight to your inbox. </p></div>',1)),d((a(),l("div",pe,[e("div",he,[k(c(K),{class:"w-6 h-6","aria-hidden":"true"})]),t[5]||(t[5]=e("h2",{class:"text-xl font-bold text-white mb-1"},"Subscribe to Our Newsletter",-1)),t[6]||(t[6]=e("p",{class:"text-sm text-white/60 mb-5"},"Join thousands of Bitcoiners getting smarter every week.",-1)),e("form",{onSubmit:t[1]||(t[1]=N(s=>E("top"),["prevent"])),class:"space-y-3"},[d(e("input",{"onUpdate:modelValue":t[0]||(t[0]=s=>M.value=s),type:"email",placeholder:"satoshi@example.com",class:"email-input",autocomplete:"email","aria-label":"Email address"},null,512),[[T,M.value]]),e("button",{type:"submit",class:"btn-primary w-full",disabled:x.value},[x.value?(a(),p(c(D),{key:0,class:"w-4 h-4 animate-spin","aria-hidden":"true"})):(a(),p(c(P),{key:1,class:"w-4 h-4","aria-hidden":"true"})),u(" "+m(x.value?"Subscribing…":"Subscribe Now"),1)],8,ye)],32),V.value?(a(),l("p",ve,[k(c(j),{class:"w-4 h-4 shrink-0","aria-hidden":"true"}),t[4]||(t[4]=u(" You're in! Check your inbox for a welcome message. ",-1))])):f("",!0),_.value?(a(),l("p",ke,[k(c(A),{class:"w-4 h-4 shrink-0","aria-hidden":"true"}),u(" "+m(_.value),1)])):f("",!0)])),[[h,{delay:60}]])])]),e("section",be,[e("div",xe,[d((a(),l("div",ge,[...t[8]||(t[8]=[e("p",{class:"eyebrow"},"What You'll Receive",-1),e("h2",{id:"value-title",class:"section-title mt-2"},"Knowledge That Compounds",-1),e("p",{class:"lead max-w-2xl mx-auto mt-4"},"Every edition is designed to make you a more informed, confident Bitcoin holder.",-1)])])),[[h]]),e("div",fe,[(a(),l(w,null,L(R,(s,y)=>d(e("div",{key:s.title,class:"value-card"},[e("div",we,[(a(),p(B(s.icon),{class:"w-5 h-5","aria-hidden":"true"}))]),e("h3",Me,m(s.title),1),e("p",_e,m(s.desc),1)]),[[h,{delay:60*(y+1)}]])),64))])])]),e("section",Ce,[e("div",Se,[d((a(),l("div",Le,[...t[9]||(t[9]=[e("p",{class:"eyebrow"},"Community",-1),e("h2",{id:"topics-title",class:"section-title mt-2"},[u("Trusted by Bitcoiners Who Do"),e("br",{class:"hidden sm:block"}),u(" Their Own Research")],-1)])])),[[h]]),d((a(),l("div",Be,[e("div",Ve,[t[10]||(t[10]=e("p",{class:"text-sm text-white/70 leading-relaxed"}," Our subscribers include individual holders, family offices, and institutional investors who value signal over noise. ",-1)),e("div",ze,[(a(),l(w,null,L(q,s=>e("div",{key:s.text,class:"trust-row"},[e("span",Ee,[(a(),p(B(s.icon),{class:"w-4 h-4","aria-hidden":"true"}))]),e("span",Ne,m(s.text),1)])),64))])]),e("div",Te,[t[11]||(t[11]=e("p",{class:"text-sm font-semibold text-white/90 mb-3"},"Topics We Cover",-1)),e("div",Ae,[(a(),l(w,null,L(U,s=>e("div",{key:s.label,class:"topic-chip"},[(a(),p(B(s.icon),{class:"w-4 h-4 topic-chip-icon","aria-hidden":"true"})),e("span",null,m(s.label),1)])),64))])])])),[[h,{delay:60}]])])]),e("section",je,[d((a(),l("div",De,[t[13]||(t[13]=e("h2",{id:"cta-title",class:"section-title"},"Start Learning Today",-1)),t[14]||(t[14]=e("p",{class:"lead max-w-xl mx-auto mt-3 mb-8"}," No spam, no fluff — just the Bitcoin education that matters. Unsubscribe anytime. ",-1)),e("form",{onSubmit:t[3]||(t[3]=N(s=>E("bottom"),["prevent"])),class:"cta-form"},[d(e("input",{"onUpdate:modelValue":t[2]||(t[2]=s=>C.value=s),type:"email",placeholder:"you@example.com",class:"email-input flex-1",autocomplete:"email","aria-label":"Email address"},null,512),[[T,C.value]]),e("button",{type:"submit",class:"btn-primary shrink-0",disabled:g.value},[g.value?(a(),p(c(D),{key:0,class:"w-4 h-4 animate-spin","aria-hidden":"true"})):(a(),p(c(P),{key:1,class:"w-4 h-4","aria-hidden":"true"})),u(" "+m(g.value?"Subscribing…":"Subscribe"),1)],8,Pe)],32),z.value?(a(),l("p",Re,[k(c(j),{class:"w-4 h-4 shrink-0","aria-hidden":"true"}),t[12]||(t[12]=u(" You're in! Check your inbox for a welcome message. ",-1))])):f("",!0),S.value?(a(),l("p",Ue,[k(c(A),{class:"w-4 h-4 shrink-0","aria-hidden":"true"}),u(" "+m(S.value),1)])):f("",!0)])),[[h]])])]),k(Y)],64))}},Ke=H(qe,[["__scopeId","data-v-9a61570c"]]);export{Ke as default};
