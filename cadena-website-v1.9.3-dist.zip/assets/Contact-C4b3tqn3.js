import{M as P,d,e as l,f as t,N as D,_ as j,r as S,o as G,q as J,h as q,s as w,F as W,i as Q,v as f,k as F,t as A,x as g,z as ee,g as N,O,P as te,Q as ie,T as se,p as ae,j as Y,D as U}from"./index-BVQmVtzd.js";import{T as oe}from"./TheFooter-CW7_ylDB.js";const ne={viewBox:"0 0 24 24",width:"1.2em",height:"1.2em"};function le(r,s){return l(),d("svg",ne,[...s[0]||(s[0]=[t("path",{fill:"currentColor",d:"M23.498 6.186a3.02 3.02 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.02 3.02 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.02 3.02 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.02 3.02 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814M9.545 15.568V8.432L15.818 12z"},null,-1)])])}const re=P({name:"simple-icons-youtube",render:le}),ce={viewBox:"0 0 24 24",width:"1.2em",height:"1.2em"};function de(r,s){return l(),d("svg",ce,[...s[0]||(s[0]=[t("path",{fill:"currentColor",d:"M12 .297c-6.63 0-12 5.373-12 12c0 5.303 3.438 9.8 8.205 11.385c.6.113.82-.258.82-.577c0-.285-.01-1.04-.015-2.04c-3.338.724-4.042-1.61-4.042-1.61C4.422 18.07 3.633 17.7 3.633 17.7c-1.087-.744.084-.729.084-.729c1.205.084 1.838 1.236 1.838 1.236c1.07 1.835 2.809 1.305 3.495.998c.108-.776.417-1.305.76-1.605c-2.665-.3-5.466-1.332-5.466-5.93c0-1.31.465-2.38 1.235-3.22c-.135-.303-.54-1.523.105-3.176c0 0 1.005-.322 3.3 1.23c.96-.267 1.98-.399 3-.405c1.02.006 2.04.138 3 .405c2.28-1.552 3.285-1.23 3.285-1.23c.645 1.653.24 2.873.12 3.176c.765.84 1.23 1.91 1.23 3.22c0 4.61-2.805 5.625-5.475 5.92c.42.36.81 1.096.81 2.22c0 1.606-.015 2.896-.015 3.286c0 .315.21.69.825.57C20.565 22.092 24 17.592 24 12.297c0-6.627-5.373-12-12-12"},null,-1)])])}const pe=P({name:"simple-icons-github",render:de}),ue={viewBox:"0 0 24 24",width:"1.2em",height:"1.2em"};function me(r,s){return l(),d("svg",ue,[...s[0]||(s[0]=[t("path",{fill:"currentColor",d:"M14.234 10.162L22.977 0h-2.072l-7.591 8.824L7.251 0H.258l9.168 13.343L.258 24H2.33l8.016-9.318L16.749 24h6.993zm-2.837 3.299l-.929-1.329L3.076 1.56h3.182l5.965 8.532l.929 1.329l7.754 11.09h-3.182z"},null,-1)])])}const he=P({name:"simple-icons-x",render:me}),Z="/img/kevinb-640.avif",ye="/img/kevinb-960.avif",ve="/img/kevinb-1280.avif",X="/img/Sz-640.avif",fe="/img/Sz-960.avif",we="/img/Sz-1280.avif";/**
 * @license lucide-vue-next v0.534.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const H=r=>r.replace(/([a-z0-9])([A-Z])/g,"$1-$2").toLowerCase(),ge=r=>r.replace(/^([A-Z])|[\s-_]+(\w)/g,(s,y,v)=>v?v.toUpperCase():y.toLowerCase()),xe=r=>{const s=ge(r);return s.charAt(0).toUpperCase()+s.slice(1)},be=(...r)=>r.filter((s,y,v)=>!!s&&s.trim()!==""&&v.indexOf(s)===y).join(" ").trim();/**
 * @license lucide-vue-next v0.534.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */var $={xmlns:"http://www.w3.org/2000/svg",width:24,height:24,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor","stroke-width":2,"stroke-linecap":"round","stroke-linejoin":"round"};/**
 * @license lucide-vue-next v0.534.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const _e=({size:r,strokeWidth:s=2,absoluteStrokeWidth:y,color:v,iconNode:o,name:b,class:B,..._},{slots:m})=>D("svg",{...$,width:r||$.width,height:r||$.height,stroke:v||$.stroke,"stroke-width":y?Number(s)*24/Number(r):s,class:be("lucide",...b?[`lucide-${H(xe(b))}-icon`,`lucide-${H(b)}`]:["lucide-icon"]),..._},[...o.map(p=>D(...p)),...m.default?[m.default()]:[]]);/**
 * @license lucide-vue-next v0.534.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const C=(r,s)=>(y,{slots:v})=>D(_e,{...y,iconNode:s,name:r},v);/**
 * @license lucide-vue-next v0.534.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const ke=C("building-2",[["path",{d:"M6 22V4a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v18Z",key:"1b4qmf"}],["path",{d:"M6 12H4a2 2 0 0 0-2 2v6a2 2 0 0 0 2 2h2",key:"i71pzd"}],["path",{d:"M18 9h2a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2h-2",key:"10jefs"}],["path",{d:"M10 6h4",key:"1itunk"}],["path",{d:"M10 10h4",key:"tcdvrf"}],["path",{d:"M10 14h4",key:"kelpxr"}],["path",{d:"M10 18h4",key:"1ulq68"}]]);/**
 * @license lucide-vue-next v0.534.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const K=C("check",[["path",{d:"M20 6 9 17l-5-5",key:"1gmf2c"}]]);/**
 * @license lucide-vue-next v0.534.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Ce=C("chevron-down",[["path",{d:"m6 9 6 6 6-6",key:"qrunsl"}]]);/**
 * @license lucide-vue-next v0.534.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const V=C("copy",[["rect",{width:"14",height:"14",x:"8",y:"8",rx:"2",ry:"2",key:"17jyea"}],["path",{d:"M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2",key:"zix9uf"}]]);/**
 * @license lucide-vue-next v0.534.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Be=C("mail",[["path",{d:"m22 7-8.991 5.727a2 2 0 0 1-2.009 0L2 7",key:"132q7q"}],["rect",{x:"2",y:"4",width:"20",height:"16",rx:"2",key:"izxlao"}]]);/**
 * @license lucide-vue-next v0.534.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Te=C("phone",[["path",{d:"M13.832 16.568a1 1 0 0 0 1.213-.303l.355-.465A2 2 0 0 1 17 15h3a2 2 0 0 1 2 2v3a2 2 0 0 1-2 2A18 18 0 0 1 2 4a2 2 0 0 1 2-2h3a2 2 0 0 1 2 2v3a2 2 0 0 1-.8 1.6l-.468.351a1 1 0 0 0-.292 1.233 14 14 0 0 0 6.392 6.384",key:"9njp5v"}]]);/**
 * @license lucide-vue-next v0.534.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Le=C("user",[["path",{d:"M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2",key:"975kel"}],["circle",{cx:"12",cy:"7",r:"4",key:"17ys0d"}]]);/**
 * @license lucide-vue-next v0.534.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Se=C("users",[["path",{d:"M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2",key:"1yyitq"}],["path",{d:"M16 3.128a4 4 0 0 1 0 7.744",key:"16gr8j"}],["path",{d:"M22 21v-2a4 4 0 0 0-3-3.87",key:"kshegd"}],["circle",{cx:"9",cy:"7",r:"4",key:"nufk8"}]]),Me={class:"w-full px-6 py-5 md:py-8","aria-labelledby":"usecases-title"},ze={class:"max-w-6xl mx-auto space-y-8"},$e=["id","tabindex","aria-selected","onClick"],Ae={class:"hc-title"},Ee={key:0,class:"hc-active-title","aria-live":"polite"},Ie={class:"hc-title-out"},Ye=["aria-labelledby"],De={class:"mt-2 text-white leading-relaxed"},Ne=["innerHTML"],Oe={__name:"UseCasesAccordion",props:{items:{type:Array,default:()=>[]}},setup(r,{expose:s}){const y=r,v=y.items.findIndex(e=>(e==null?void 0:e.open)===!0),o=S(v>=0?v:null),b=Math.random().toString(36).slice(2),B=`uc-panel-${b}`,_=e=>`uc-tab-${b}-${e}`,m=S(null);let p,T=!1;function h(){return m.value?{top:m.value.getBoundingClientRect().top}:{top:0}}function i(e){if(!m.value)return;const a=m.value.getBoundingClientRect().top-e.top;a!==0&&window.scrollTo(0,window.scrollY+a)}async function u(e){if(T)return;T=!0;const n=h();L(e),await ae(),await new Promise(a=>requestAnimationFrame(a)),await new Promise(a=>requestAnimationFrame(a)),i(n),T=!1}function L(e){o.value=o.value===e?null:e}function x(e){const n=document.getElementById(_(e));n&&n.focus&&n.focus({preventScroll:!0})}function M(e){const n=y.items.length;if(!n)return;const a=o.value===null?0:o.value;switch(e.key){case"ArrowRight":case"Right":{e.preventDefault();const c=(a+1)%n;o.value=c,x(c);break}case"ArrowLeft":case"Left":{e.preventDefault();const c=(a-1+n)%n;o.value=c,x(c);break}case"Home":{e.preventDefault(),o.value=0,x(0);break}case"End":{e.preventDefault(),o.value=n-1,x(n-1);break}case" ":case"Enter":{e.preventDefault(),o.value=o.value===a?null:a;break}}}const E={onBeforeEnter(e){e.style.height="0px",e.style.opacity="0",e.style.transform="translateY(-6px)",e.style.overflow="hidden",e.__ro&&e.__ro.disconnect(),e.__ro=null},onEnter(e,n){const a="cubic-bezier(.22,.61,.36,1)";e.style.transition=`height 420ms ${a}, opacity 360ms ease, transform 420ms ${a}`;const c=new ResizeObserver(()=>{e.style.height=e.scrollHeight+"px"});c.observe(e),e.__ro=c,requestAnimationFrame(()=>{e.style.height=e.scrollHeight+"px",e.style.opacity="1",e.style.transform="translateY(0)"});const k=z=>{if(z.propertyName!=="height")return;c.disconnect(),e.__ro=null;const I=e.style.transition;e.style.transition="opacity 200ms ease, transform 200ms ease",e.style.height="auto",requestAnimationFrame(()=>{e.style.transition=I,e.style.overflow="",n()}),e.removeEventListener("transitionend",k)};e.addEventListener("transitionend",k)},onBeforeLeave(e){e.style.height=e.scrollHeight+"px",e.style.opacity="1",e.style.transform="translateY(0)",e.style.overflow="hidden",e.__ro&&(e.__ro.disconnect(),e.__ro=null)},onLeave(e,n){const a="cubic-bezier(.22,.61,.36,1)";e.style.transition=`height 340ms ${a}, opacity 260ms ease, transform 340ms ${a}`,requestAnimationFrame(()=>{e.style.height="0px",e.style.opacity="0",e.style.transform="translateY(-6px)"});const c=k=>{k.propertyName==="height"&&(e.removeEventListener("transitionend",c),n())};e.addEventListener("transitionend",c)}},R={mounted(e,n){var z;e.classList.add("reveal");const a=Number(((z=n==null?void 0:n.value)==null?void 0:z.delay)??0),c=Number.isFinite(a)&&a>=0&&a<=2e3?a:0;e.style.transitionDelay=`${c}ms`;const k=new IntersectionObserver(([I])=>{I.isIntersecting&&(e.classList.add("in"),k.unobserve(e))},{rootMargin:"0px 0px -10% 0px",threshold:.08});k.observe(e)}};return s({vReveal:R}),G(()=>{if("ResizeObserver"in window&&m.value){let e=m.value.getBoundingClientRect().top;p=new ResizeObserver(()=>{if(!m.value)return;const a=m.value.getBoundingClientRect().top-e;a!==0&&!T&&window.scrollTo(0,window.scrollY+a),e=m.value.getBoundingClientRect().top}),p.observe(m.value)}}),J(()=>{p&&m.value&&p.disconnect()}),(e,n)=>(l(),d("section",Me,[t("div",ze,[n[0]||(n[0]=t("h2",{id:"usecases-title",class:"section-title text-center"},"Use cases",-1)),t("div",{class:"hc-wrap",ref_key:"wrapRef",ref:m},[t("div",{class:"hc-list",role:"tablist","aria-label":"Use case list",onKeydown:M},[(l(!0),d(W,null,Q(r.items,(a,c)=>f((l(),d("button",{key:a.id??c,class:F(["pro-card hc-card group",{"is-active":o.value===c}]),role:"tab",id:_(c),tabindex:o.value===null?c===0?0:-1:o.value===c?0:-1,"aria-selected":o.value===c?"true":"false","aria-controls":B,onClick:k=>u(c)},[t("div",Ae,A(a.title),1),w(g(Ce),{class:F(["chev w-5 h-5 shrink-0 ml-auto transition-transform duration-200",{"rotate-180":o.value===c}]),"aria-hidden":"true"},null,8,["class"])],10,$e)),[[R,{delay:c*60}]])),128))],32),o.value!==null?(l(),d("div",Ee,[t("h3",Ie,A(r.items[o.value].title),1)])):q("",!0),w(se,te(ie(E)),{default:ee(()=>[o.value!==null?(l(),d("div",{class:"pro-card hc-panel is-panel",role:"tabpanel",id:B,"aria-labelledby":_(o.value),key:"hc-panel"},[t("div",De,[typeof r.items[o.value].content=="string"?(l(),d("div",{key:0,innerHTML:r.items[o.value].content},null,8,Ne)):(l(),N(O(r.items[o.value].content),{key:1}))])],8,Ye)):q("",!0)]),_:1},16)],512)])]))}},Pe=j(Oe,[["__scopeId","data-v-c9ed68a4"]]),Re=Z+" 640w, "+ye+" 960w, "+ve+" 1280w",qe=X+" 640w, "+fe+" 960w, "+we+" 1280w",Fe={class:"min-h-screen text-white relative overflow-hidden bg-page-gradient"},Ue={class:"w-full pt-0 md:pt-0","aria-labelledby":"onboarding-title"},He={class:"mx-auto max-w-screen-xl px-6 sm:px-8 lg:px-12 space-y-10"},Ke={class:"text-center"},Ve={class:"grid grid-cols-1 md:grid-cols-2 gap-6"},je={class:"pro-card group"},Ge={class:"flex items-start gap-4"},We={class:"icon-wrap"},Ze={class:"flex-1"},Xe={class:"mt-5 flex flex-wrap items-center gap-3"},Je=["aria-label"],Qe={class:"text-sm font-medium"},et={class:"pro-card group"},tt={class:"flex items-start gap-4"},it={class:"icon-wrap"},st={class:"flex-1"},at={class:"mt-5 flex flex-wrap items-center gap-3"},ot=["aria-label"],nt={class:"text-sm font-medium"},lt={class:"w-full px-6 py-16 md:py-20"},rt={class:"max-w-6xl mx-auto space-y-10"},ct={class:"section-title text-center"},dt={class:"space-y-8"},pt={class:"grid grid-cols-1 md:grid-cols-3 gap-6"},ut={class:"reveal glass-tile card-tight text-center group"},mt={class:"reveal glass-tile card-tight text-center group"},ht={class:"reveal glass-tile card-tight text-center group"},yt={class:"reveal glass-card text-center"},vt={class:"w-full px-6 pb-16 md:pb-24"},ft={class:"max-w-6xl mx-auto space-y-12"},wt={class:"section-title text-center"},gt={class:"reveal glass-card"},xt={class:"flex flex-wrap items-center justify-center gap-10 md:gap-12"},bt={href:"https://x.com/cadenabitcoin",target:"_blank",rel:"noopener noreferrer nofollow",referrerpolicy:"no-referrer","aria-label":"Visit us on X (Twitter)",class:"social-tile"},_t={href:"https://github.com/CadenaWizard/oracle",target:"_blank",rel:"noopener noreferrer nofollow",referrerpolicy:"no-referrer","aria-label":"Visit our GitHub repository",class:"social-tile"},kt={href:"https://youtube.com/@cadenabitcoin?si=VNgOLehpTTVFELbt",target:"_blank",rel:"noopener noreferrer nofollow",referrerpolicy:"no-referrer","aria-label":"Visit our YouTube",class:"social-tile"},Ct={class:"grid grid-cols-1 md:grid-cols-2 gap-8"},Bt={class:"reveal glass-card"},Tt={class:"reveal glass-card"},Lt={__name:"Contact",setup(r){const s=S(!1),y=S(!1),v=S(!1);function o(){B("info@cadenabitcoin.com",s)}function b(){B("+13058311410",y)}function B(h,i){var u;(u=navigator.clipboard)!=null&&u.writeText?navigator.clipboard.writeText(h).then(()=>m(i)).catch(()=>_(h,i)):_(h,i)}function _(h,i){const u=document.createElement("textarea");u.value=h,u.setAttribute("readonly",""),u.style.position="absolute",u.style.left="-9999px",document.body.appendChild(u),u.select();try{document.execCommand("copy"),m(i)}finally{document.body.removeChild(u)}}function m(h){h.value=!0,v.value=!0,setTimeout(()=>{h.value=!1,v.value=!1},1500)}G(()=>{window.scrollTo(0,0)});const p={mounted(h,i){var M;h.classList.add("reveal");const u=Number(((M=i==null?void 0:i.value)==null?void 0:M.delay)??0),L=Number.isFinite(u)&&u>=0&&u<=2e3?u:0;h.style.transitionDelay=`${L}ms`;const x=new IntersectionObserver(([E])=>{E.isIntersecting&&(h.classList.add("in"),x.unobserve(h))},{rootMargin:"0px 0px -10% 0px",threshold:.08});x.observe(h)}},T=[{title:"“Mini Saylor” — Corporate Bitcoin Strategy",teaser:"Amplify BTC exposure without selling or draining cash.",content:`
      <p class="text-white/80">You're a Bitcoin maximalist who believes BTC will outperform long-term, but you want to add exposure without selling your stack or depleting cash.</p>

      <p class="mt-4 font-semibold text-white">Meet Alex: The Bitcoin Entrepreneur</p>
      <p class="text-white/80">“I run a tech company and hold 5 BTC personally. I’m convinced Bitcoin will hit $500K, but I don’t want to sell or use all my business capital to buy more.”</p>

      <p class="mt-4 font-semibold text-white">The Cadena Solution — Leverage Your Conviction, Keep Your Keys</p>
      <ul class="list-disc pl-5 space-y-1 text-white/80">
        <li>Decide how much additional exposure you want.</li>
        <li>Borrow additional Bitcoin based on risk tolerance and objectives.</li>
        <li>Use borrowed Bitcoin to increase your total position.</li>
        <li>Loan is settled in Bitcoin at term end (30, 90, 180 days, or 1 year).</li>
      </ul>

      <p class="mt-4 font-semibold text-white">The Process</p>
      <ol class="list-decimal pl-5 space-y-1 text-white/80">
        <li>Register on Cadena and download the signer app.</li>
        <li>Borrow additional Bitcoin at market rates (execute online, sign in app).</li>
        <li>Amplify your Bitcoin exposure without selling.</li>
        <li>Settle the loan in Bitcoin at maturity.</li>
      </ol>

      <p class="mt-4 font-semibold text-white">The Outcome</p>
      <ul class="list-disc pl-5 space-y-1 text-white/80">
        <li>✅ Increase your exposure from 0.05 BTC up to 5× stack leverage.</li>
        <li>✅ No taxable event — you never sold your original stack.</li>
        <li>✅ True self-custody throughout.</li>
        <li>✅ No KYC or banks — pure peer-to-peer Bitcoin finance.</li>
      </ul>

      <p class="mt-4 italic text-white/75">“Just like MicroStrategy’s strategy, but truly decentralized.”</p>

      <a href="/register" class="btn-primary mt-5 inline-flex" aria-label="Get Started">Get Started →</a>
    `},{title:"“Dividend Debbie” — Stable Bitcoin Yield",teaser:"Predictable BTC-denominated yield with custody intact.",content:`
      <p class="text-white/80">You want steady returns above traditional savings, without bank counterparty risk—while staying aligned with Bitcoin’s long-term upside.</p>

      <p class="mt-4 font-semibold text-white">Meet Debbie: The Yield Seeker</p>
      <p class="text-white/80">“I have 10 BTC sitting idle. Banks offer 0.5% while taking huge risks with my money. I want steady Bitcoin-denominated returns with real security.”</p>

      <p class="mt-4 font-semibold text-white">The Cadena Solution — Earn Yield, Keep Control</p>
      <ul class="list-disc pl-5 space-y-1 text-white/80">
        <li>Lend your Bitcoin on Cadena’s marketplace to earn fixed returns.</li>
        <li>Your Bitcoin is secured by math and Bitcoin collateral on-chain.</li>
        <li>No counterparty risk — borrower collateral protects your principal.</li>
        <li>You understand the risk of BTC moving below the loan-to-value over the term.</li>
      </ul>

      <p class="mt-4 font-semibold text-white">The Process</p>
      <ol class="list-decimal pl-5 space-y-1 text-white/80">
        <li>Register and download Cadena’s signer app.</li>
        <li>Choose lending terms (30, 90, 180 days, or 1 year).</li>
        <li>Set your desired yield rate; use a market or limit order.</li>
        <li>Match with borrowers.</li>
        <li>Earn Bitcoin-denominated returns.</li>
      </ol>

      <p class="mt-4 font-semibold text-white">The Outcome</p>
      <ul class="list-disc pl-5 space-y-1 text-white/80">
        <li>✅ Predictable yield — fiat-style yield, denominated in Bitcoin.</li>
        <li>✅ Your keys, your coins — maintain custody.</li>
        <li>✅ No bank risk — peer-to-peer with mathematical security.</li>
      </ul>

      <p class="mt-4 italic text-white/75">“Like being a preferred shareholder in MicroStrategy, but with better security.”</p>

      <a href="/register" class="btn-primary mt-5 inline-flex" aria-label="Start Lending">Start Lending →</a>
    `},{title:"“Borrowing for the Boat” — Liquidity Without Selling",teaser:"Access $50K without selling BTC or triggering tax.",content:`
      <p class="text-white/80">You need $50,000 for a purchase but don’t want to sell BTC, miss potential upside, or trigger a taxable event.</p>

      <p class="mt-4 font-semibold text-white">Meet Captain Mike: The Bitcoin HODLer</p>
      <p class="text-white/80">“I need $50K for my dream boat, but selling Bitcoin feels like selling Amazon in 1999. There has to be a better way.”</p>

      <p class="mt-4 font-semibold text-white">The Cadena Solution — Access Liquidity, Keep Your Bitcoin</p>
      <ul class="list-disc pl-5 space-y-1 text-white/80">
        <li>Use your Bitcoin as collateral for a Bitcoin loan.</li>
        <li>Borrow Bitcoin to maintain your desired exposure.</li>
        <li>Convert borrowed Bitcoin to USD for your purchase.</li>
        <li>Repay the loan by buying back Bitcoin at maturity.</li>
      </ul>

      <p class="mt-4 font-semibold text-white">The Process (example)</p>
      <ol class="list-decimal pl-5 space-y-1 text-white/80">
        <li>Borrow 0.5 BTC for 1 year (assuming BTCUSD = $100,000).</li>
        <li>Convert borrowed BTC to USD on your exchange of choice.</li>
        <li>Buy your boat with the proceeds.</li>
        <li>At term end, buy back $50,000 worth of Bitcoin and repay the loan.</li>
      </ol>

      <p class="mt-4 font-semibold text-white">The Outcome</p>
      <ul class="list-disc pl-5 space-y-1 text-white/80">
        <li>✅ Get your boat without selling your stack.</li>
        <li>✅ Maintain upside — you still own your original BTC.</li>
        <li>✅ True self-custody — your keys, your control.</li>
        <li>• Conservative risk management: 50% LTV gives a wide buffer.</li>
        <li>• No margin calls: collateral only matters at final settlement.</li>
      </ul>

      <p class="mt-4 italic text-white/75">“Enjoy life today while staying positioned for Bitcoin’s future.”</p>

      <a href="/register" class="btn-primary mt-5 inline-flex" aria-label="Borrow Now">Borrow Now →</a>
    `},{title:"“Yield Arber” — Advanced Bitcoin Strategies",teaser:"Capture spreads while keeping BTC exposure.",content:`
      <p class="text-white/80">You’re sophisticated with capital and want to maximize returns by arbitraging between BTC lending rates and other opportunities—without sacrificing exposure.</p>

      <p class="mt-4 font-semibold text-white">Meet Sarah: The Yield Arbitrageur</p>
      <p class="text-white/80">“I see Cadena lenders earning ~10% while I can borrow fiat at ~5%, or have savings sitting idle. I want to increase the dollar value of my BTC position by earning yield on my stack.”</p>

      <p class="mt-4 font-semibold text-white">The Cadena Solution — The Spread Play</p>
      <ul class="list-disc pl-5 space-y-1 text-white/80">
        <li>Lend Bitcoin on Cadena while borrowing fiat elsewhere at lower rates.</li>
        <li>✅ Maximize capital efficiency.</li>
        <li>✅ Maintain Bitcoin exposure.</li>
        <li>✅ Keep full custody — minimize counterparty risk.</li>
      </ul>

      <p class="mt-4 font-semibold text-white">Risk Considerations</p>
      <ul class="list-disc pl-5 space-y-1 text-white/80">
        <li>Leverage involves risk.</li>
        <li>Understand settlement mechanics.</li>
        <li>Plan for multiple BTC price scenarios.</li>
      </ul>

      <p class="mt-4 italic text-white/75">“For those who understand Bitcoin deeply and want to maximize every satoshi.”</p>

      <a href="/register" class="btn-primary mt-5 inline-flex" aria-label="Explore Opportunities">Explore Opportunities →</a>
    `}];return(h,i)=>{const u=he,L=pe,x=re;return l(),d(W,null,[t("div",Fe,[i[21]||(i[21]=t("div",{class:"bg-fixed-gradient","aria-hidden":"true"},null,-1)),i[22]||(i[22]=t("div",{class:"glow-purple","aria-hidden":"true"},null,-1)),i[23]||(i[23]=t("div",{class:"glow-cyan","aria-hidden":"true"},null,-1)),t("section",Ue,[t("div",He,[f((l(),d("div",Ke,[...i[0]||(i[0]=[t("h1",{id:"onboarding-title",class:"section-title"}," Personalized Onboarding ",-1),t("p",{class:"lead max-w-4xl mx-auto"}," As a Cadena Bitcoin client, expert knowledge is always just a chat, email, or phone call away. We simplify complexity and are available 24/7 for personalized onboarding and strategies to borrow Bitcoin or generate yield from Bitcoin. ",-1)])])),[[p]]),t("div",Ve,[f((l(),d("div",je,[t("div",Ge,[t("div",We,[w(g(Te),{class:"w-5 h-5","aria-hidden":"true"})]),t("div",Ze,[i[2]||(i[2]=t("h4",{class:"text-2xl font-semibold"},"Call",-1)),i[3]||(i[3]=t("p",{class:"text-sm text-white/70 mt-1"},"Speak to our team anytime.",-1)),t("div",Xe,[i[1]||(i[1]=t("a",{href:"tel:+13058311410",class:"btn-primary","aria-label":"Call (305) 831-1410"}," (305) 831-1410 ",-1)),t("button",{onClick:b,class:"btn-ghost","aria-label":y.value?"Copied phone number":"Copy phone number"},[(l(),N(O(y.value?g(K):g(V)),{class:"w-4 h-4"})),t("span",Qe,A(y.value?"Copied":"Copy"),1)],8,Je)]),i[4]||(i[4]=t("div",{class:"mt-4 flex items-center gap-3 text-xs text-white/60"},[t("span",{class:"inline-flex items-center gap-1"},[t("span",{class:"h-1.5 w-1.5 rounded-full bg-emerald-400/80"}),Y(" Live support ")]),t("span",null,"Response time: < 24h")],-1))])])])),[[p,{delay:60}]]),f((l(),d("div",et,[t("div",tt,[t("div",it,[w(g(Be),{class:"w-5 h-5","aria-hidden":"true"})]),t("div",st,[i[6]||(i[6]=t("h4",{class:"text-2xl font-semibold"},"Email",-1)),i[7]||(i[7]=t("p",{class:"text-sm text-white/70 mt-1"},"Send us your questions or request onboarding.",-1)),t("div",at,[i[5]||(i[5]=t("a",{href:"mailto:info@cadenabitcoin.com",class:"btn-primary","aria-label":"Email info@cadenabitcoin.com"}," info@cadenabitcoin.com ",-1)),t("button",{onClick:o,class:"btn-ghost","aria-label":s.value?"Copied email":"Copy email"},[(l(),N(O(s.value?g(K):g(V)),{class:"w-4 h-4"})),t("span",nt,A(s.value?"Copied":"Copy"),1)],8,ot)]),i[8]||(i[8]=t("div",{class:"mt-4 flex items-center gap-3 text-xs text-white/60"},[t("span",null,"Dedicated onboarding specialist"),t("span",{"aria-hidden":"true"},"•"),t("span",null,"Secure & private")],-1))])])])),[[p,{delay:100}]])])])]),t("section",lt,[t("div",rt,[f((l(),d("h2",ct,[...i[9]||(i[9]=[Y("Who we serve.",-1)])])),[[p]]),t("div",dt,[t("div",pt,[f((l(),d("div",ut,[w(g(Le),{class:"w-8 h-8 mx-auto mb-3 text-white/80 group-hover:text-white","aria-hidden":"true"}),i[10]||(i[10]=t("p",{class:"text-xl font-semibold"},"Individual Investors",-1))])),[[p,{delay:40}]]),f((l(),d("div",mt,[w(g(Se),{class:"w-8 h-8 mx-auto mb-3 text-white/80 group-hover:text-white","aria-hidden":"true"}),i[11]||(i[11]=t("p",{class:"text-xl font-semibold"},"Family Offices",-1))])),[[p,{delay:90}]]),f((l(),d("div",ht,[w(g(ke),{class:"w-8 h-8 mx-auto mb-3 text-white/80 group-hover:text-white","aria-hidden":"true"}),i[12]||(i[12]=t("p",{class:"text-xl font-semibold"},"Institutional Investors",-1))])),[[p,{delay:140}]])]),f((l(),d("div",yt,[...i[13]||(i[13]=[t("p",{class:"text-2xl text-white/90"}," Get expert support and competitive rates for Bitcoin borrowing and lending. ",-1)])])),[[p,{delay:180}]])])])]),w(Pe,{items:T}),t("section",vt,[t("div",ft,[f((l(),d("h2",wt,[...i[14]||(i[14]=[Y("Reach Out",-1)])])),[[p]]),f((l(),d("div",gt,[i[18]||(i[18]=t("p",{class:"text-2xl font-semibold mb-8 text-center"},"Find Us On Social Media",-1)),t("div",xt,[t("a",bt,[w(u,{class:"w-16 h-16 md:w-20 md:h-20","aria-hidden":"true"}),i[15]||(i[15]=t("span",{class:"text-base font-medium"},"X",-1))]),t("a",_t,[w(L,{class:"w-16 h-16 md:w-20 md:h-20","aria-hidden":"true"}),i[16]||(i[16]=t("span",{class:"text-base font-medium"},"GitHub",-1))]),t("a",kt,[w(x,{class:"w-16 h-16 md:w-20 md:h-20","aria-hidden":"true"}),i[17]||(i[17]=t("span",{class:"text-base font-medium"},"YouTube",-1))])])])),[[p,{delay:60}]]),t("div",Ct,[f((l(),d("div",Bt,[...i[19]||(i[19]=[U('<div class="avatar-wrap mb-3" data-v-57621018><img src="'+Z+'" srcset="'+Re+'" sizes="(min-width: 768px) 192px, 160px" alt="Kevin Bell headshot" class="headshot" width="160" height="160" loading="lazy" decoding="async" data-v-57621018></div><p class="text-xl font-semibold mb-1" data-v-57621018>Kevin Bell</p><p class="text-sm text-white/70" data-v-57621018>President • CFA</p><p class="mt-3 text-white/80 text-sm leading-relaxed" data-v-57621018> Kevin Bell, CFA — tradfi graduate, capital markets veteran, debt and currency dealer, and numbers ninja. Passionate about building efficient financial solutions that promote Bitcoin, freedom, decentralization, and individual empowerment. </p><div class="mt-4 space-y-1" data-v-57621018><p data-v-57621018><span class="font-medium" data-v-57621018>Email:</span><a href="mailto:kevin@cadenabitcoin.com" class="underline hover:opacity-80" data-v-57621018>kevin@cadenabitcoin.com</a></p></div>',5)])])),[[p,{delay:80}]]),f((l(),d("div",Tt,[...i[20]||(i[20]=[U('<div class="avatar-wrap mb-3" data-v-57621018><img src="'+X+'" srcset="'+qe+'" sizes="(min-width: 768px) 192px, 160px" alt="Sziller headshot" class="headshot" width="160" height="160" loading="lazy" decoding="async" data-v-57621018></div><p class="text-xl font-semibold mb-1" data-v-57621018>Sziller</p><p class="text-sm text-white/70" data-v-57621018>Chief Technology Officer</p><p class="mt-3 text-white/80 text-sm leading-relaxed" data-v-57621018> Sziller, an Engineer and M.Sc. Architect with decentralization and self-sufficiency on my mind. I’m interested in Engineering solutions for real-life problems accessible to anyone, with skunkswork philosophy. I strive to achieve optimal redundancy by cutting out as many middle-men as possible. I love solutions that work, even if rough on the edges. </p><div class="mt-4 space-y-1" data-v-57621018><p data-v-57621018><span class="font-medium" data-v-57621018>Email:</span><a href="mailto:sziller@cadenabitcoin.com" class="underline hover:opacity-80" data-v-57621018>sziller@cadenabitcoin.com</a></p></div>',5)])])),[[p,{delay:120}]])])])])]),w(oe)],64)}}},zt=j(Lt,[["__scopeId","data-v-57621018"]]);export{zt as default};
